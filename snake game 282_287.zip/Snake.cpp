#include "Snake.h"
#include <GL/glut.h>

Body::Body() {

}
Body::~Body() {

}
Snake::Snake()
{
	bodies.resize(1);
}


Snake::~Snake()
{
}

void Snake::draw() {
	for (int i = 0; i < bodies.size(); i++) {
		glPushMatrix();
		glTranslatef(bodies[i].currentX-bodies[i].x, bodies[i].currentY-bodies[i].y, 0);
		glTranslatef(i, 0, 0);
		bodies[i].addPosition(i, 0);
		glutSolidSphere(1, 20, 20);
		glPopMatrix();
	}
}
void Snake::addBody() {
	Body b = Body();
	bodies.push_back(b);
}
void Snake::deleteBody() {
	bodies.pop_back();
}
void Snake::move(float newx, float newy) {
	for (int i = bodies.size()-1; i >= 1; i--) {
		bodies[i].currentX = bodies[i - 1].currentX;
		bodies[i].currentY = bodies[i - 1].currentY;
	}
	bodies[0].currentX = newx;
	bodies[0].currentY = newy;
}